<?php
include_once 'DBController.php';

$error = '';
$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numeUtilizator = $_POST['NumeUtilizator'];
    $parola = password_hash($_POST['Parola'], PASSWORD_DEFAULT);
    $nivelCompetenta = $_POST['NivelCompetenta'];
    $nume = $_POST['Nume'];
    $email = $_POST['Email'];
    $nrTelefon = $_POST['NrTelefon'];
    $dataNasterii = $_POST['DataNasterii'];
    $dataCrearii = date('Y-m-d H:i:s');

    try {
        $dbController = new DBController();
        $db = $dbController->getConnection();
    
        $db->beginTransaction();
    
        $query = "INSERT INTO users (NumeUtilizator, ParolaHash, NivelCompetenta, DataCrearii, Nume, Email, NrTelefon, DataNasterii) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $db->prepare($query);
        $stmt->execute([
            $numeUtilizator, 
            $parola, 
            $nivelCompetenta, 
            $dataCrearii, 
            $nume, 
            $email, 
            $nrTelefon, 
            $dataNasterii
        ]);
    
        $db->commit();
        $message = "Înregistrarea a fost realizată cu succes!";
        header("Location: LogIn.php");
    } catch (Exception $e) {
        $db->rollBack();
        // Afișează detalii suplimentare despre eroare
        $error = "Eroare la inserarea datelor: " . $e->getMessage();
        // Poți adăuga și detalii despre eroarea SQL specifică
        error_log($e->getMessage());  // Logarea detaliilor erorii în logurile serverului
    }
    
}
?>

<!DOCTYPE html>
<html lang="ro">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="centru de echitatie pentru iubitori de cai in cluj">
    <meta name="keyword" content="calarit, echitatie, cai, cal, cluj">
    <link rel="icon" href="images/favicon.ico">
    <link rel="stylesheet" href="css/clrimpreuna.css">
    <title id = "page-title-6">Inregistreaza-te!</title>
</head>
<body>
    <header>
    <nav class="navbar">
            <div class="branding">
                <a href="HomePage.html"><img id="logo" src="images/logo2.png" alt="logo"></a>
            </div>
            <div class="navbar-menu">
                <ul>
                    <li><a href="HomePage.html" id="nav-home">Acasă</a></li>
                    <li><a href="educational.html" id="nav-did-you-know">Știai că?</a></li>
                    <li><a href="galerie.html" id="nav-gallery">Galerie</a></li>
                    <li><a href="Programari.php" id="nav-schedule">Programează-te</a></li>
                    <li><a href="contact.html" id="nav-contact">Contactează-ne!</a></li>
                    <li><a href="LogIn.php" id="nav-login">Intră în cont</a></li>
                    <li><a href="sign_up.php" id="nav-signup">Fă-ți un cont</a></li>
                </ul>
            </div>
            <select id="language-selector">
                <option value="ro">Română</option>
                <option value="en">English</option>
                <option value="fr">Français</option>
            </select>
            <a href="#" class="toggle-button">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </a>
        </nav>
  </header>
	
  <div class="registration-form">
        <h2>Înregistrare</h2>
        
        <?php if ($error): ?>
            <div class="alert"><?= $error; ?></div>
        <?php endif; ?>
        <?php if ($message): ?>
            <div class="alert"><?= $message; ?></div>
        <?php endif; ?>

        <form action="sign_up.php" method="POST">
            <div class="form-group">
                <label for="NumeUtilizator" class="form-label">Nume Utilizator</label>
                <input type="text" id="NumeUtilizator" name="NumeUtilizator" class="form-input" required>
            </div>

            <div class="form-group">
                <label for="Parola" class="form-label">Parola</label>
                <input type="password" id="Parola" name="Parola" class="form-input" required>
            </div>

            <div class="form-group">
                <label for="NivelCompetenta" class="form-label">Nivel Competentă</label>
                <select id="NivelCompetenta" name="NivelCompetenta" class="form-input" required>
                    <option value="Începător">Începător</option>
                    <option value="Intermediar">Intermediar</option>
                    <option value="Avansat">Avansat</option>
                </select>
            </div>

            <div class="form-group">
                <label for="Nume" class="form-label">Nume</label>
                <input type="text" id="Nume" name="Nume" class="form-input" required>
            </div>

            <div class="form-group">
                <label for="Email" class="form-label">Email</label>
                <input type="email" id="Email" name="Email" class="form-input" required>
            </div>

            <div class="form-group">
                <label for="NrTelefon" class="form-label">Nr Telefon</label>
                <input type="tel" id="NrTelefon" name="NrTelefon" class="form-input" required>
            </div>

            <div class="form-group">
                <label for="DataNasterii" class="form-label">Data Nașterii</label>
                <input type="date" id="DataNasterii" name="DataNasterii" class="form-input" required>
            </div>

            <button type="submit" class="btn-submit">Înregistrează-te</button>
        </form>
    </div>

  <script src="js/toggle.js"></script>
  <script src="https://kit.fontawesome.com/fc632b9fc3.js" crossorigin="anonymous"></script>
  <script src="js/localization.js" defer></script>
</body>       
</html>
</body>
</html>

