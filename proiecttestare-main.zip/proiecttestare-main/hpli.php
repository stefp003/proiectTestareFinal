<?php

include_once "DBController.php";
session_start();
$database = new DBController();
$db = $database->getConnection(); // Se presupune că aici ai conexiunea PDO

if (isset($_SESSION['UserID'])) {
    $user_id = $_SESSION['UserID'];

    // Creează interogarea SQL pentru a selecta programările utilizatorului
    $sql = "SELECT * FROM programari WHERE UserID = :UserID";  // Folosește un parametru numit :UserID

    // Pregătește declarația pentru a preveni SQL injection
    $stmt = $db->prepare($sql);

    // Leagă parametrul 'UserID' la interogare
    $stmt->bindValue(':UserID', $user_id, PDO::PARAM_INT); // legăm parametrul UserID

    // Execută interogarea
    $stmt->execute();

    // Obține rezultatele
    $result = $stmt->fetchAll(PDO::FETCH_ASSOC); // Obține toate rezultatele


} else {
    // Mesaj dacă utilizatorul nu este autentificat
    echo "<p>Trebuie să vă autentificați pentru a vizualiza programările.</p>";
}

?>



<!DOCTYPE html>
<html>
	<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="centru de echitatie pentru iubitori de cai in cluj">
    <meta name="keyword" content="calarit, echitatie, cai, cal, cluj">
    <link rel="icon" href="images/favicon.ico">
    <link rel="stylesheet" href="css/clrimpreuna.css">
        <script src="js/localization.js" defer></script>
    <title>Acasa</title>
	</head>
	<body>
		<header>
        <header>
      
        <nav class="navbar">
            <div class="branding">
                <a href="HomePage.html"><img id="logo" src="images/logo2.png" alt="logo"></a>
            </div>
            <div class="navbar-menu">
                <ul>
                    <li><a href="HomePage.html" id="nav-home">Acasă</a></li>
                    <li><a href="educational.html" id="nav-did-you-know">Știai că?</a></li>
                    <li><a href="galerie.html" id="nav-gallery">Galerie</a></li>
                    <li><a href="Programari.php" id="nav-schedule">Programează-te</a></li>
                    <li><a href="contact.html" id="nav-contact">Contactează-ne!</a></li>
                    <li><a href="LogIn.php" id="nav-login">Intră în cont</a></li>
                    <li><a href="sign_up.php" id="nav-signup">Fă-ți un cont</a></li>
                    <li><a href="help.html" id="nav-help">Ajutor</a></li>
                </ul>
            </div>
            <select id="language-selector">
                <option value="ro">Română</option>
                <option value="en">English</option>
                <option value="fr">Français</option>
            </select>
            <a href="#" class="toggle-button">
                <span class="bar"></span>
                <span class="bar"></span>
                <span class="bar"></span>
            </a>
        </nav>
</header>
            <?php
            if ($result) {
                echo "<h2 id='appointments_title'>Programările tale:</h2>";
                // Afișează fiecare programare
                foreach ($result as $row) {
                    echo "<div class='programare'>";
                    echo "<p id='dateP'><strong id='appointment_on'>Programare pe:</strong> " . $row["data_programare"]  . " " . $row["ora"] . "</p>";
                    echo "<p id='details'><strong id='details_text'>Detalii:</strong> " . $row["mesaj"] . "</p>";
                    echo "</div>";
                }
            } else {
                echo "<p id='noAppointments'>Nu aveți programări.</p>";
            }
            ?>
	</body>
</html>